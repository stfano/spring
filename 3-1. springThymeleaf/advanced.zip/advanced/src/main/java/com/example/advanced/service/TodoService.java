package com.example.advanced.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.advanced.database.dao.TodoDao;
import com.example.advanced.model.dto.TodoDto;
import com.example.advanced.model.entity.TodoEntity;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class TodoService {
    
    @Autowired
    private TodoDao todoDao;

    public List<TodoDto> selectAll() {
        log.info("[TodoService][selectTodoAll] Start");

        List<TodoEntity> entityList = todoDao.selectAll();

        List<TodoDto> todoList = new ArrayList<>();
        for(TodoEntity entity:entityList) {
            TodoDto dto = new TodoDto(entity.getId(), entity.getTitle(), entity.getStatus());
            todoList.add(dto);
        }

        return todoList;
    }

    public void insertDto(TodoDto dto)
    {
        log.info("[TodoService][insertDto] 안니영~ ");

        dto.setStatus("false");
        TodoEntity entity = new TodoEntity();
        entity.setTitle(dto.getTitle());
        entity.setStatus(dto.getStatus());

        todoDao.insertDto(entity);
    }   

    public void updateDto(Long id)
    {
        log.info("[TodoService][insertDto] 안니영~ ");

        TodoEntity entity = new TodoEntity();
        entity.setId(id);
        entity.setStatus("true");
        todoDao.updateDto(entity);
    }  

    public void deleteDto(Long id)
    {
        log.info("[TodoService][insertDto] 안니영~ ");

        todoDao.deleteDto(id);
    }  
}
