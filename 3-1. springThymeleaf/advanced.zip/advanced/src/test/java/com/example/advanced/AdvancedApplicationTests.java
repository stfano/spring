package com.example.advanced;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvancedApplicationTests {

	@Test
	void contextLoads() {
	}

}
